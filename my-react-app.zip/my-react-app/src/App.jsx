import React, { useState } from 'react';
import './App.css';
import Verify from './verify';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';

// Custom Tick SVG component
const TickIcon = () => (
  <svg className="tickIcon" viewBox="0 0 24 24" width="24" height="24">
    <path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
  </svg>
);

function App() {
  const [isUploaded, setIsUploaded] = useState(false);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setIsUploaded(true);
    }
  };

  return (
    <Router>
      <div className="appContainer">
        <nav>
          <div className="nav-half">
            <Link to="/" className="nav-button">Upload</Link>
          </div>
          <div className="nav-half">
            <Link to="/verify" className="nav-button">Verify</Link>
          </div>
        </nav>

        <Routes>
          <Route path="/" element={
            <div className="uploadBox">
              <h2>Upload File</h2>
              <input 
                type="file" 
                onChange={handleFileUpload} 
                style={{ display: 'none' }} 
                id="fileInput"
              />
              <button 
                className="actionButton uploadButton" 
                onClick={() => document.getElementById('fileInput').click()}
              >
                Choose File
              </button>
              
              {isUploaded && (
                <div className="resultMessage">
                  <span className="successIcon"><TickIcon /></span>
                  <p>File uploaded successfully!</p>
                </div>
              )}
            </div>
          } />
          <Route path="/verify" element={<Verify />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;